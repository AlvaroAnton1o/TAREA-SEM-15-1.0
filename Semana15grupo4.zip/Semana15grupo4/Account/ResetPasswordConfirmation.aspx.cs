﻿using System.Web.UI;

namespace Semana15grupo4.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}