﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Semana15grupo4.Startup))]
namespace Semana15grupo4
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
